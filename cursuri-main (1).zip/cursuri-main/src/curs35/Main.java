package curs35;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/exemplu2";
    private static final String USER="root";
    private static final String PASSWORD="";

    private static int id = 20;
    private static String email = "exemplu@gmail.com";

    public static void main(String[] args) {
        String prepareStatement = "SELECT * from students where email=?";
        String storedProcedureCall = "{call selectEmail(?)}";

        try(Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
//            PreparedStatement preparedStatement =  connection.prepareStatement(prepareStatement);
//            CallableStatement clbStatement = connection.prepareCall(storedProcedureCall)
        ) {

//            statementInsert();
            statementSelect(statement);
//            statementUpdateNext(statement);
//            preparedStatement(preparedStatement);

//            callableStatement(clbStatement);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    private static void statementUpdateNext(Statement statement)  throws SQLException {
        String select = "SELECT * from students";
       ResultSet resultSet = statement.executeQuery(select);
       resultSet.moveToInsertRow();

       resultSet.updateInt(1,id);
       resultSet.updateString("firstname", "Andrei");
       resultSet.updateString("lastname","Mircea");
       resultSet.updateString(4, email);
       resultSet.updateDate(5, Date.valueOf("1997-10-10"));
       resultSet.insertRow();
    }

    private static void callableStatement(CallableStatement clbStatement) throws SQLException {
        clbStatement.setString(1, "alexandru.marin@gmail.com");
        ResultSet resultSet = clbStatement.executeQuery();
    }

    private static void preparedStatement(PreparedStatement preparedStatement) throws SQLException {
        preparedStatement.setString(1,"alexandru.marin@gmail.com");
        ResultSet resultSet = preparedStatement.executeQuery();
        preparedStatement.setString(1,"marinica@gmail.com");
        preparedStatement.executeQuery();
    }

    private static void statementSelect(Statement statement) throws SQLException {
        String select = "SELECT * from students";
        try( ResultSet resultSet = statement.executeQuery(select)){
            List<Student> studentList = new ArrayList<>();
            while (resultSet.next()){
                Student student = new Student();
                student.setId(resultSet.getInt("id"));
                student.setFirstname(resultSet.getString(2));
                student.setLastname(resultSet.getString(3));
                student.setEmail(resultSet.getString(4));
                student.setBirthdate(resultSet.getDate(5));
                studentList.add(student);
            }
            studentList.forEach(System.out::println);
        };
    }

    private static void statementInsert() {
        String insertAStudent = "INSERT INTO students VALUES (null, 'Ionut', 'Marin', 'marinica@gmail.com', '1998/2/24')";
        String insertAPerson = "INSERT INTO people VALUES (null, 'Ionut', 'Marin', 'marinica@gmail.com')";

//            statement.executeUpdate(insertAStudent);
//            statement.executeUpdate(insertAPerson);
    }
}
