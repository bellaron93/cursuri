package cursDemo;

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("DEMO");
    }
}
