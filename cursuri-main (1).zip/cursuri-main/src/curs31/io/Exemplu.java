package curs31.io;

public class Exemplu {

    public static void main(String[] args) {
        byte a = 65;
        System.out.println(a);
        char asChar = (char) a;
        System.out.println(asChar);
    }
}
