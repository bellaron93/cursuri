import java.util.function.Consumer;
import java.util.function.UnaryOperator;

public class Demo {
    public static void main(String[] args) {
        Consumer<String> stringConsumer = System.out::println;

        UnaryOperator<String> name = input -> input.substring(0,1).toUpperCase() + input.substring(1).toLowerCase();
        System.out.println(name.apply("aleXanDRu"));
    }


}
