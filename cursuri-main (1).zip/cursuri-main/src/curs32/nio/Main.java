package curs32.nio;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        Path path = Path.of("resource/nio/info.txt");
        Path copie = Path.of("resource/nio/info2.txt");
        System.out.println(path.getParent());

        if(Files.exists(path)){
            System.out.println("fisierul exista deja");
        }
        if(Files.exists(copie)){
            System.out.println("exista");
        }

       /* try {
            Files.copy(path,copie);
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        if(Files.isRegularFile(copie)){
            System.out.println("e fisier, nu director");
        }

        try(BufferedReader reader =  Files.newBufferedReader(path)) {
            System.out.println(reader.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            List<String> allLines = Files.readAllLines(path);
            allLines.stream().forEach(linie -> System.out.println("LINIE: " + linie));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
