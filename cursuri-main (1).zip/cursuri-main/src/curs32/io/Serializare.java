package curs32.io;

import java.io.*;
import java.time.LocalDate;

public class Serializare {

    public static void main(String[] args)  {
        Person alex = new Person(24, "Alex",
                LocalDate.of(1980,3,24),
                new Food("placinta"));
        System.out.println(alex);

        File resource = new File("resource/people.txt");
        try(ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(resource));
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(resource))
        ) {
            outputStream.writeObject(alex);
            Person alexJr = (Person)inputStream.readObject();
            System.out.println(alexJr);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
