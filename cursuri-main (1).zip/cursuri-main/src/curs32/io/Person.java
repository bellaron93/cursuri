package curs32.io;

import java.io.Serializable;
import java.time.LocalDate;

public class Person implements Serializable {

    private static final long serialVersionUID = 1L;

    private int age;
    private String name;
    private LocalDate birthDate;
    private Food food;

    public Person(int age, String name,LocalDate birthDate, Food food) {
        this.age = age;
        this.name = name;
        this.birthDate = birthDate;
        this.food = food;
    }

    @Override
    public String toString() {
        return "Person{" +
                "age=" + age +
                ", name='" + name + '\'' +
                ", birthDate=" + birthDate +
                ", food=" + food +
                '}';
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
