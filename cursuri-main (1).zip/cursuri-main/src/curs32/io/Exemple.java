package curs32.io;

import java.io.*;

public class Exemple {

    public static void main(String[] args) throws IOException {
        File resource = new File("resource");
        if(!resource.exists()){
            resource.mkdir();
        }
        File app = new File(resource, "application.properties");
        if(!app.exists()){
            app.createNewFile();
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(app))){

            String s = reader.readLine();

//            System.out.println(s);
            reader.skip(1);
            System.out.println(reader.readLine());
//            System.out.println(reader.readLine());
        }catch (Exception e){

        }
    }
}
