package curs32.io;

import java.io.Serializable;

public class Food implements Serializable {

    private String name;

    public Food(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Food{" +
                "name='" + name + '\'' +
                '}';
    }
}
