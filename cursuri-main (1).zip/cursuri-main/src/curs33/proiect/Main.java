package curs33.proiect;

import curs33.proiect.constants.Commands;
import curs33.proiect.logic.AirLineManager;
import curs33.proiect.logic.ReaderManager;

import static curs33.proiect.constants.Commands.LOGIN;
import static curs33.proiect.constants.Commands.SIGNUP;

public class Main {

    public static void main(String[] args) {
        AirLineManager airLineManager = new AirLineManager();
        ReaderManager readerManager = new ReaderManager();

        String line = readerManager.readLine();
        while (line != null) {
            //procesam comanda de pe line
            String[] arguments = line.split(" ");

            //EVENTUAL: tratat si in caz de exceptie sa se foloseasca o comanda default
            System.out.println("------" + arguments[0]);
            Commands command = Commands.valueOf(arguments[0]);

            switch (command) {
                case SIGNUP: {
                    //procesare specifica
                    airLineManager.signUp(arguments);
                    break;
                }
                case LOGIN: {
                    airLineManager.login(arguments);
                    break;
                }
                case ADD_FLIGHT_DETAILS: {
                    airLineManager.addFlight(arguments);
                    break;
                }
                case DELETE_FLIGHT: {
                    airLineManager.deleteFlight(arguments);
                }
                //TODO de completat cu case uri
            }

            //trecem la urmatoarea linie
            line = readerManager.readLine();
        }
    }
}
