package curs33.proiect.constants;

public enum Commands {

    SIGNUP,
    LOGIN,
    DELETE_FLIGHT,
    ADD_FLIGHT_DETAILS
}
