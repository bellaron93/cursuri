package curs33.proiect.data;

import java.util.ArrayList;
import java.util.List;

public class User {

    private String email;
    private String name;
    private String parola;

    private List<Flight> userFlights = new ArrayList<>();

    public User(String email, String name, String parola) {
        this.email = email;
        this.name = name;
        this.parola = parola;
    }

    public void addFlight(Flight flight){
        userFlights.add(flight);
    }

    public void deleteFlight(Flight flight){
        userFlights.remove(flight);
    }

    public List<Flight> getUserFlights() {
        return userFlights;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getParola() {
        return parola;
    }

    @Override
    public String toString() {
        return "User{" +
                "email='" + email + '\'' +
                ", name='" + name + '\'' +
                ", parola='" + parola + '\'' +
                '}';
    }
}
