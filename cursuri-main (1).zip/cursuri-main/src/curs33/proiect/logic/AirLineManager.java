package curs33.proiect.logic;

import curs33.proiect.data.Flight;
import curs33.proiect.data.User;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static curs33.proiect.constants.Messages.cannotAddUserPasswordDiff;
import static curs33.proiect.constants.Messages.cannotFindUserWithEmail;

public class AirLineManager {
    //TODO update constructor writerManager
    private WriterManager writerManager = new WriterManager(null);
    //colectie utilizatori
    private List<User> allUsers = new ArrayList<>();
    private User currentUser;
    //colectie zboruri
    private List<Flight> allFlights = new ArrayList<>();

    public void signUp(String[] arguments) {
        String email = arguments[1];
        String name = arguments[2];
        String password = arguments[3];
        String password2 = arguments[4];

        //TODO daca exista deja utilizatorul
        //validari
        if(!password.equals(password2)){
           writerManager.write(cannotAddUserPasswordDiff());
        } else if(password.length() < 8){
            System.out.println("Cannot add user! Password too short!");
        }else {
            //caz fericit
            User user = new User(email, name, password);
            //TODO adaugat in colectia de useri
            allUsers.add(user);
            System.out.println("User with email: " + user.getEmail() + " was successfully added!");
        }
    }

    public void login(String[] arguments) {
        String email = arguments[1];
        String parola = arguments[2];

        Optional<User> optionalUser = allUsers.stream()
                .filter(user -> user.getEmail().equals(email))
                .findFirst();

        if(optionalUser.isEmpty()){
            System.out.println(cannotFindUserWithEmail(email));
            return;
        }

        User user = optionalUser.get();
        if(!user.getParola().equals(parola)){
            System.out.println( "Incorrect password!");
            return;
        }

        if(currentUser != null){
            System.out.println("Another user is already connected!");
            return;
        }
        currentUser = user;
    }

    public void logout(String[] arguments){
        //TODO sa facem null userul curent daca sunt verificate toate cerintele
        currentUser = null;
    }

    public void deleteFlight(String[] arguments) {
        Optional<Flight> optionalFlight = allFlights.stream()
                .filter(flight -> flight.getId() == Integer.parseInt(arguments[1]))
                .findFirst();
        if(optionalFlight.isEmpty()){
            System.out.println("The flight with id "+ arguments[1] + "does not exist!");
            return;
        }

        Flight flight = optionalFlight.get();
        allFlights.remove(flight);
        System.out.println("Flight with id <flight_id> successfully deleted");

        //anunt toti userii
        for( User user: allUsers){
            if(user.getUserFlights().contains(flight)) {
                user.deleteFlight(flight);
                System.out.println("The user with email <email> was notified that the flight with id <flight_id> was canceled!");
            }
        }
    }

    //TODO de implementat cu validari
    public void addFlight(String[] arguments) {
        Flight flight = new Flight(1,"Bucuresti", "Viena", LocalDate.now(), 120);
        allFlights.add(flight);
    }
}
