package curs33.proiect.logic;

public class AirlineStatistics {

    private static String findMostUsedCityAsDepartureForFlights(AirLineManager airLineManager){
        return null;
    }

}
